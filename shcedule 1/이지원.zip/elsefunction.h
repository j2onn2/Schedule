void menu_printing (void)	;
void dash_printing (void)   ;


